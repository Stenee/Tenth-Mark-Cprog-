/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a=100;
    int b=99;
    int c=80;
    int d=95;
    int e=91;
    int total=465;
    printf("mark in Tamil:%d\n",a);
    printf("mark in English:%d\n",b);
    printf("mark in Maths:%d\n",c);
    printf("mark in Science:%d\n",d);
    printf("mark in Social:%d\n",e);
    printf("Total marks:%d\n",total);

    return 0;
}
